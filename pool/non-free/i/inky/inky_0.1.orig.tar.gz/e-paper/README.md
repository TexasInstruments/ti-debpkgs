﻿# Build

```
cmake -B build
cmake --build build
```

# Run

```
./build/inky
```

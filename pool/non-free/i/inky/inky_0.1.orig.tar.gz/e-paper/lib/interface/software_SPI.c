#include <stdlib.h>
#include <stdio.h>

#include <stdint.h> 
#include <unistd.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <getopt.h> 
#include <fcntl.h> 
#include <sys/ioctl.h> 
#include <linux/types.h>

#include "../interface/DEV_Config.h"
#include "../interface/gpio.h"
#include "../interface/spi.h"

struct gpiod_line *gpio_CS_line;
struct gpiod_line *gpio_MOSI_line;
struct gpiod_line *gpio_SCLK_line;

static void DEV_SPI_SendData(uint8_t byte)
{
	for (uint8_t i = 0; i < 8; i++)
	{
		GPIOD_Write(gpio_SCLK_line, 0);
		if (byte & 0x80)
			GPIOD_Write(gpio_MOSI_line, 1);
		else
			GPIOD_Write(gpio_MOSI_line, 0);

		GPIOD_Write(gpio_SCLK_line, 1);
		byte <<= 1;
	}
	GPIOD_Write(gpio_SCLK_line, 0);
}

int DEV_SPI_Transfer(uint8_t *data, uint32_t len)
{
	uint32_t i;
	GPIOD_Write(gpio_CS_line, 0);
	for (i = 0; i < len; i++)
		DEV_SPI_SendData(data[i]);
	GPIOD_Write(gpio_CS_line, 1);

	return 1;
}

void DEV_SPI_Init(void)
{
	printf("Using GPIO Software SPI\n");

	gpio_CS_line = GPIOD_Export(EPD_CS_PIN, GPIOD_OUT);
	gpio_MOSI_line = GPIOD_Export(EPD_MOSI_PIN, GPIOD_OUT);
	gpio_SCLK_line = GPIOD_Export(EPD_SCLK_PIN, GPIOD_OUT);
//	DEV_Digital_Write(EPD_CS_PIN, 1);
}

void DEV_SPI_Exit(void)
{
//	DEV_Digital_Write(EPD_CS_PIN, 0);
	GPIOD_Unexport(gpio_CS_line);
	GPIOD_Unexport(gpio_MOSI_line);
	GPIOD_Unexport(gpio_SCLK_line);
}

#ifndef _SPI_H
#define _SPI_H

#include <stdint.h>

void DEV_SPI_Init(void);
void DEV_SPI_Exit(void);

int DEV_SPI_Transfer(uint8_t *buf, uint32_t len);

#endif /* _SPI_H */

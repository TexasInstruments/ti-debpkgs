#ifndef __GPIOD_
#define __GPIOD_

#include <stdio.h>
#include <gpiod.h>

#define GPIOD_IN  0
#define GPIOD_OUT 1

#define GPIOD_LOW  0
#define GPIOD_HIGH 1

#define GPIOD_DEBUG 1
#if GPIOD_DEBUG 
	#define GPIOD_Debug(__info,...) printf("Debug: " __info,##__VA_ARGS__)
#else
	#define GPIOD_Debug(__info,...)  
#endif 

int GPIOD_Init();
void GPIOD_Exit(void);
struct gpiod_line_request *GPIOD_Export(unsigned int offset, int dir);
void GPIOD_Unexport(struct gpiod_line_request *gpioline);
int GPIOD_Read(struct gpiod_line_request *gpioline);
int GPIOD_Write(struct gpiod_line_request *gpioline, int value);

#endif

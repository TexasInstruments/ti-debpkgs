#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "DEV_Config.h"
#include "gpio.h"
#include "spi.h"

/* GPIO */
//struct gpiod_line_request *gpio_PWR_line;
struct gpiod_line_request *gpio_RST_line;
struct gpiod_line_request *gpio_DC_line;
struct gpiod_line_request *gpio_BUSY_line;

//int current_rst = 0;
//int current_dc = 0;

/**
 * GPIO read and write
**/
void DEV_Digital_Write_RST(uint8_t value)
{
	GPIOD_Write(gpio_RST_line, value);
//	if (current_rst != value) {
//		printf("SET RST: %d\n", value);
//		current_rst = value;
//	}
}

void DEV_Digital_Write_DC(uint8_t value)
{
	GPIOD_Write(gpio_DC_line, value);
//	if (current_dc != value) {
////		printf("SET DC: %d\n", value);
//		current_dc = value;
//	}
}

uint8_t DEV_Digital_Read_BUSY()
{
	return GPIOD_Read(gpio_BUSY_line);
//	return 0;
}

/**
 * SPI
**/
void DEV_SPI_WriteByte(uint8_t value)
{
	DEV_SPI_Transfer(&value, 1);
//	printf("SPI %s: 0x%02x\n", current_dc == 0 ? "CMD" : "DATA", Value);
}

void DEV_SPI_Write_nByte(uint8_t *data, uint32_t len)
{
	DEV_SPI_Transfer(data, len);
}

/**
 * delay x ms
 **/
void DEV_Delay_ms(uint32_t xms)
{
	usleep(xms * 1000);
}

void DEV_GPIO_Init(void)
{
	GPIOD_Init();

//	gpio_PWR_line = GPIOD_Export(EPD_PWR_PIN, GPIOD_OUT);
	gpio_RST_line = GPIOD_Export(EPD_RST_PIN, GPIOD_OUT);
	gpio_DC_line = GPIOD_Export(EPD_DC_PIN, GPIOD_OUT);
	gpio_BUSY_line = GPIOD_Export(EPD_BUSY_PIN, GPIOD_IN);

//	DEV_Digital_Write(EPD_PWR_PIN, 1);
}

void DEV_GPIO_Exit(void)
{
//	DEV_Digital_Write(EPD_PWR_PIN, 0);
//	DEV_Digital_Write(EPD_RST_PIN, 0);

//	GPIOD_Unexport(EPD_PWR_PIN);
	GPIOD_Unexport(gpio_BUSY_line);
	GPIOD_Unexport(gpio_DC_line);
	GPIOD_Unexport(gpio_RST_line);
	GPIOD_Exit();
}

uint8_t DEV_Module_Init(void)
{
	DEV_GPIO_Init();
	DEV_SPI_Init();

	return 0;
}

void DEV_Module_Exit(void)
{
	DEV_SPI_Exit();
	DEV_GPIO_Exit();
}

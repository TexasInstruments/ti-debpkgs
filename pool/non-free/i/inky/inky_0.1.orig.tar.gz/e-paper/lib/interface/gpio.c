#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <gpiod.h>

#include "DEV_Config.h"
#include "gpio.h"

struct gpiod_chip *gpiochip;

int GPIOD_Init()
{
	gpiochip = gpiod_chip_open(GPIOD_NAME);
	if (gpiochip == NULL)
	{
		GPIOD_Debug("Failed to export: " GPIOD_NAME "\n");
		return -1;
	}

	return 0;
}

void GPIOD_Exit(void)
{
	gpiod_chip_close(gpiochip);
}

struct gpiod_line_request *GPIOD_Export(unsigned int offset, int dir)
{
	struct gpiod_line_settings *settings = gpiod_line_settings_new();
	if (!settings)
		return NULL;

	gpiod_line_settings_set_direction(settings, dir ? GPIOD_LINE_DIRECTION_OUTPUT : GPIOD_LINE_DIRECTION_INPUT);
	gpiod_line_settings_set_output_value(settings, GPIOD_LINE_VALUE_INACTIVE);

	struct gpiod_line_config *line_cfg = gpiod_line_config_new();
	if (!line_cfg)
		goto free_settings;

	int ret = gpiod_line_config_add_line_settings(line_cfg, &offset, 1, settings);
	if (ret)
		goto free_line_config;

	return gpiod_chip_request_lines(gpiochip, NULL, line_cfg);

free_line_config:
	gpiod_line_config_free(line_cfg);

free_settings:
	gpiod_line_settings_free(settings);

	return NULL;
}

unsigned int gpiod_line_offset(struct gpiod_line_request *gpioline)
{
	unsigned int offset;
	gpiod_line_request_get_requested_offsets(gpioline, &offset, 1);
	return offset;
}

void GPIOD_Unexport(struct gpiod_line_request *gpioline)
{
	GPIOD_Debug("Unexporting Pin %d\n", gpiod_line_offset(gpioline));

	gpiod_line_request_release(gpioline);
}

int GPIOD_Write(struct gpiod_line_request *gpioline, int value)
{
	enum gpiod_line_value values = value ? GPIOD_LINE_VALUE_ACTIVE : GPIOD_LINE_VALUE_INACTIVE;
	int ret = gpiod_line_request_set_values(gpioline, &values);
	if (ret)
		GPIOD_Debug("Failed to write value to Pin %d\n", gpiod_line_offset(gpioline));
	return ret;
}

int GPIOD_Read(struct gpiod_line_request *gpioline)
{
	enum gpiod_line_value values;
	int ret = gpiod_line_request_get_values(gpioline, &values);
	if (ret < 0)
		GPIOD_Debug("Failed to read value from Pin %d\n", gpiod_line_offset(gpioline));
	return (values == GPIOD_LINE_VALUE_ACTIVE) ? 1 : 0;
}

#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <stdint.h>

#define GPIOD_NAME "/dev/gpiochip0"

//#define EPD_PWR_PIN 18
#define EPD_RST_PIN 16
#define EPD_DC_PIN 17
#define EPD_BUSY_PIN 15

#ifdef HW_SPI
#define SPI_DEV_NAME "/dev/spidev1.0"
#else
#define EPD_CS_PIN 14
#define EPD_MOSI_PIN 36
#define EPD_SCLK_PIN 33
#endif

/*------------------------------------------------------------------------------------------------------*/
void DEV_Digital_Write_RST(uint8_t value);
void DEV_Digital_Write_DC(uint8_t value);
uint8_t DEV_Digital_Read_BUSY();

void DEV_SPI_WriteByte(uint8_t value);
void DEV_SPI_Write_nByte(uint8_t *pData, uint32_t Len);

void DEV_Delay_ms(uint32_t xms);

uint8_t DEV_Module_Init(void);
void DEV_Module_Exit(void);

#endif

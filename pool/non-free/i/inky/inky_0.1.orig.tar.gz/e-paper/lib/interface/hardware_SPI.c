#include <stdlib.h>
#include <stdio.h>

#include <stdint.h> 
#include <unistd.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <getopt.h> 
#include <fcntl.h> 
#include <sys/ioctl.h> 
#include <linux/types.h> 
#include <linux/spi/spidev.h> 

#include "../interface/DEV_Config.h"
#include "../interface/spi.h"

/**
 * Define SPI attribute
**/
typedef struct SPIStruct {
    uint32_t speed;
    uint16_t mode;
    uint16_t delay;
    uint8_t bits;
    int fd;
} HARDWARE_SPI;


HARDWARE_SPI hardware_SPI;

static uint8_t bits = 8;

void DEV_SPI_Init(void)
{
	printf("Using SPIDEV: " SPI_DEV_NAME "\n");

	if ((hardware_SPI.fd = open(SPI_DEV_NAME, O_RDWR)) < 0) {
		printf("Failed to open SPI device\r");
		exit(1);
	}

	hardware_SPI.bits = bits;

	if (ioctl(hardware_SPI.fd, SPI_IOC_WR_BITS_PER_WORD, &hardware_SPI.bits) == -1) {
		printf("can't set bits per word\n");
		exit(1);
	}
	if (ioctl(hardware_SPI.fd, SPI_IOC_RD_BITS_PER_WORD, &hardware_SPI.bits) == -1) {
		printf("can't get bits per word\n");
		exit(1);
	}

	hardware_SPI.mode = SPI_LSB_FIRST;
	// Write mode
	if (ioctl(hardware_SPI.fd, SPI_IOC_WR_MODE, &hardware_SPI.mode) == -1) {
		printf("can't set spi mode\n");
		//exit(1);
	}

	hardware_SPI.speed = 1000000;

	// Write speed
	if (ioctl(hardware_SPI.fd, SPI_IOC_WR_MAX_SPEED_HZ, &hardware_SPI.speed) == -1) {
		printf("can't set max speed hz\n");
		exit(1);
	}

	// Read back
	if (ioctl(hardware_SPI.fd, SPI_IOC_RD_MAX_SPEED_HZ, &hardware_SPI.speed) == -1) {
		printf("can't get max speed hz\n");
		exit(1);
	}

	hardware_SPI.delay = 5;
}

void DEV_SPI_Exit(void)
{
	hardware_SPI.mode = 0;
	if (close(hardware_SPI.fd) != 0) {
		perror("Failed to close SPI device.\n");
	}
}

int DEV_SPI_Transfer(uint8_t *buf, uint32_t len)
{
	struct spi_ioc_transfer tr = {0};

	tr.bits_per_word = hardware_SPI.bits;
	tr.speed_hz = hardware_SPI.speed;
	tr.delay_usecs = hardware_SPI.delay;
	tr.len = len;
	tr.tx_buf = (unsigned long)buf;
	tr.rx_buf = (unsigned long)buf;

	//ioctl Operation, transmission of data
	if (ioctl(hardware_SPI.fd, SPI_IOC_MESSAGE(1), &tr) < 1) {
		printf("can't send spi message\n");
		return -1;
	}

	return 1;
}

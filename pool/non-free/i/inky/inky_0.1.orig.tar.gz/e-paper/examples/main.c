﻿#include <stdlib.h>     //exit()
#include <signal.h>     //signal()
#include <string.h>
#include <stdint.h>

#include "EPD_4in2_V2.h"
#include "GUI_Paint.h"
#include "GUI_BMPfile.h"
#include "ImageData.h"
#include "DEV_Config.h"

static void Handler(int signo)
{
	(void)signo;

	//System Exit
	printf("Handler: exit\n");
	DEV_Module_Exit();

	exit(0);
}

const char *get_image_path(const char *filename) {
	_Thread_local static char path[256];

	if (access("/usr/share/inky/pic", F_OK) == 0) {
		strcpy(path, "/usr/share/inky/pic/");
		strcat(path, filename);
	}
	else if (access("./pic", F_OK) == 0) {
		strcpy(path, "./pic/");
		strcat(path, filename);
	}

	return path;
}

static int Show_Black_White_Image(void)
{
	// Allocate memory for image
	uint16_t ImageSize = ((EPD_4IN2_V2_WIDTH % 8 == 0) ? (EPD_4IN2_V2_WIDTH / 8) : (EPD_4IN2_V2_WIDTH / 8 + 1)) * EPD_4IN2_V2_HEIGHT;
	uint8_t *ImageData = (uint8_t*)malloc(ImageSize);
	if (ImageData == NULL) {
		printf("Failed to allocate memory\n");
		return -1;
	}

	// Draw image to memory
	Paint_NewImage(ImageData, EPD_4IN2_V2_WIDTH, EPD_4IN2_V2_HEIGHT, 0, WHITE);
	Paint_Clear(WHITE);
	GUI_ReadBmp(get_image_path("100x100.bmp"), 10, 10);

	// Display image
	printf("Showing black and white BMP\n");
	EPD_4IN2_V2_Init();
	EPD_4IN2_V2_Display(ImageData);

	free(ImageData);

	return 0;
}

static int Show_Black_White_Image_Fast(void)
{
	// Allocate memory for image
	uint16_t ImageSize = ((EPD_4IN2_V2_WIDTH % 8 == 0) ? (EPD_4IN2_V2_WIDTH / 8) : (EPD_4IN2_V2_WIDTH / 8 + 1)) * EPD_4IN2_V2_HEIGHT;
	uint8_t *ImageData = (uint8_t*)malloc(ImageSize);
	if (ImageData == NULL) {
		printf("Failed to allocate memory\n");
		return -1;
	}

	// Draw on image memory
	Paint_NewImage(ImageData, EPD_4IN2_V2_WIDTH, EPD_4IN2_V2_HEIGHT, 0, WHITE);
	Paint_Clear(WHITE);
	GUI_ReadBmp(get_image_path("4in2.bmp"), 0, 0);

	// Display image
	printf("Showing fast black and white BMP\n");
	EPD_4IN2_V2_Init_Fast(Seconds_1_5S);
	EPD_4IN2_V2_Display_Fast(ImageData);

	free(ImageData);

	return 0;
}

static int Show_Black_White_Image_Draw(void)
{
	// Allocate memory for image
	uint16_t ImageSize = ((EPD_4IN2_V2_WIDTH % 8 == 0) ? (EPD_4IN2_V2_WIDTH / 8) : (EPD_4IN2_V2_WIDTH / 8 + 1)) * EPD_4IN2_V2_HEIGHT;
	uint8_t *ImageData = (uint8_t*)malloc(ImageSize);
	if (ImageData == NULL) {
		printf("Failed to allocate memory\n");
		return -1;
	}

	// Draw on image memory
	Paint_NewImage(ImageData, EPD_4IN2_V2_WIDTH, EPD_4IN2_V2_HEIGHT, 0, WHITE);
	Paint_Clear(WHITE);
	Paint_DrawPoint(10, 80, BLACK, DOT_PIXEL_1X1, DOT_STYLE_DFT);
	Paint_DrawPoint(10, 90, BLACK, DOT_PIXEL_2X2, DOT_STYLE_DFT);
	Paint_DrawPoint(10, 100, BLACK, DOT_PIXEL_3X3, DOT_STYLE_DFT);
	Paint_DrawLine(20, 70, 70, 120, BLACK, DOT_PIXEL_1X1, LINE_STYLE_SOLID);
	Paint_DrawLine(70, 70, 20, 120, BLACK, DOT_PIXEL_1X1, LINE_STYLE_SOLID);
	Paint_DrawRectangle(20, 70, 70, 120, BLACK, DOT_PIXEL_1X1, DRAW_FILL_EMPTY);
	Paint_DrawRectangle(80, 70, 130, 120, BLACK, DOT_PIXEL_1X1, DRAW_FILL_FULL);
	Paint_DrawCircle(45, 95, 20, BLACK, DOT_PIXEL_1X1, DRAW_FILL_EMPTY);
	Paint_DrawCircle(105, 95, 20, WHITE, DOT_PIXEL_1X1, DRAW_FILL_FULL);
	Paint_DrawLine(85, 95, 125, 95, BLACK, DOT_PIXEL_1X1, LINE_STYLE_DOTTED);
	Paint_DrawLine(105, 75, 105, 115, BLACK, DOT_PIXEL_1X1, LINE_STYLE_DOTTED);

	// Display image
	printf("Showing black and white drawing\n");
	EPD_4IN2_V2_Init_Fast(Seconds_1_5S);
	EPD_4IN2_V2_Display(ImageData);

	free(ImageData);

	return 0;
}

static int Show_Gray_BMP_Image(void)
{
	// Allocate memory for image
	uint16_t ImageSize = ((EPD_4IN2_V2_WIDTH % 8 == 0) ? (EPD_4IN2_V2_WIDTH / 4) : (EPD_4IN2_V2_WIDTH / 4 + 1)) * EPD_4IN2_V2_HEIGHT;
	uint8_t *ImageData = (uint8_t*)malloc(ImageSize);
	if (ImageData == NULL) {
		printf("Failed to allocate memory\n");
		return -1;
	}

	// Draw on image memory
	Paint_NewImage(ImageData, EPD_4IN2_V2_WIDTH, EPD_4IN2_V2_HEIGHT, 0, WHITE);
	Paint_SetScale(4);
	Paint_Clear(WHITE);
	GUI_ReadBmp_4Gray(get_image_path("4in2_Scale.bmp"), 0, 0);

	// Display image
	printf("Showing Grayscale BMP\n");
	EPD_4IN2_V2_Init_4Gray();
	EPD_4IN2_V2_Display_4Gray(ImageData);

	free(ImageData);

	return 0;
}

static int Show_Gray_Image(void)
{
	// Display image
	printf("Showing Grayscale Image\n");
	EPD_4IN2_V2_Init_4Gray();
	EPD_4IN2_V2_Display_4Gray(gImage_4in2_4Gray1);

	return 0;
}

int main(void)
{
	// Exception handling:ctrl + c
	signal(SIGINT, Handler);

	printf("EPD_4IN2_V2_test Demo\n");
	if (DEV_Module_Init() != 0) {
		return -1;
	}

	Show_Black_White_Image();
	DEV_Delay_ms(2000);

	Show_Black_White_Image_Fast();
	DEV_Delay_ms(2000);

	Show_Black_White_Image_Draw();
	DEV_Delay_ms(2000);

	Show_Gray_BMP_Image();
	DEV_Delay_ms(2000);

	Show_Gray_Image();
	DEV_Delay_ms(2000);

	printf("Going to Sleep...\n");
	EPD_4IN2_V2_Sleep();
	DEV_Delay_ms(2000); //important, at least 2s

	DEV_Module_Exit();

	return 0;
}

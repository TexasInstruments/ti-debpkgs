/*************************************************************************/ /*!
@File
@Title          FW image information

@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Utility functions used internally for HWPerf data retrieval
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#if !defined(RGX_FW_INFO_H)
#define RGX_FW_INFO_H

#include "img_types.h"
#include "rgx_common.h"

/*
 * Firmware binary block unit in bytes.
 * Raw data stored in FW binary will be aligned to this size.
 */
#define FW_BLOCK_SIZE 4096L

typedef enum
{
	META_CODE = 0,
	META_PRIVATE_DATA,
	META_PRIVATE_RODATA,
	META_COREMEM_CODE,
	META_COREMEM_DATA,
	MIPS_CODE,
	MIPS_EXCEPTIONS_CODE,
	MIPS_BOOT_CODE,
	MIPS_PRIVATE_DATA,
	MIPS_PRIVATE_RODATA,
	MIPS_BOOT_DATA,
	MIPS_STACK,
	RISCV_UNCACHED_CODE,
	RISCV_CACHED_CODE,
	RISCV_PRIVATE_DATA,
	RISCV_PRIVATE_RODATA,
	RISCV_COREMEM_CODE,
	RISCV_COREMEM_DATA,
} RGX_FW_SECTION_ID;

typedef enum
{
	NONE = 0,
	FW_CODE,
	FW_RWDATA,
	FW_RODATA,
	FW_COREMEM_CODE,
	FW_COREMEM_DATA
} RGX_FW_SECTION_TYPE;


/*
 * FW binary format with FW info attached:
 *
 *          Contents        Offset
 *     +-----------------+
 *     |                 |    0
 *     |                 |
 *     | Original binary |
 *     |      file       |
 *     |   (.ldr/.elf)   |
 *     |                 |
 *     |                 |
 *     +-----------------+
 *     |   Device info   |  FILE_SIZE - 4K - ui32DeviceInfoSize
 *     +-----------------+
 *     | FW info header  |  FILE_SIZE - 4K
 *     +-----------------+
 *     |                 |
 *     | FW layout table |
 *     |                 |
 *     +-----------------+
 *                          FILE_SIZE
 */

#define FW_INFO_VERSION  (3)

/* Firmware is built for open source driver and uses open source version numbering */
#define FW_INFO_FLAGS_OPEN_SOURCE (1U)

#if defined(SUPPORT_OPEN_SOURCE_DRIVER_FIRMWARE)
#define FW_VERSION_MAJ OS_FW_MAJOR
#define FW_VERSION_MIN OS_FW_MINOR
#else
#define FW_VERSION_MAJ PVRVERSION_MAJ
#define FW_VERSION_MIN PVRVERSION_MIN
#endif

#define FW_VERSION_BUILD PVRVERSION_BUILD

typedef struct
{
	/* FW_INFO_VERSION 1 */
	IMG_UINT32 ui32InfoVersion;      /* FW info version */
	IMG_UINT32 ui32HeaderLen;        /* Header length */
	IMG_UINT32 ui32LayoutEntryNum;   /* Number of entries in the layout table */
	IMG_UINT32 ui32LayoutEntrySize;  /* Size of an entry in the layout table */
	IMG_UINT64 RGXFW_ALIGN ui64BVNC; /* BVNC */
	IMG_UINT32 ui32FwPageSize;       /* Page size of processor on which firmware executes */
	IMG_UINT32 ui32Flags;            /* Compatibility flags */

	/* FW_INFO_VERSION 2 */
	IMG_UINT16 ui16PVRVersionMajor;  /* DDK major version number */
	IMG_UINT16 ui16PVRVersionMinor;  /* DDK minor version number */
	IMG_UINT32 ui32PVRVersionBuild;  /* DDK build number */

	/* FW_INFO_VERSION 3 */
	IMG_UINT32 ui32DeviceInfoSize;   /* Device info size (in bytes). */
	IMG_UINT32 ui32Padding;
} RGX_FW_INFO_HEADER;

typedef struct
{
	RGX_FW_SECTION_ID eId;
	RGX_FW_SECTION_TYPE eType;
	IMG_UINT32 ui32BaseAddr;
	IMG_UINT32 ui32MaxSize;
	IMG_UINT32 ui32AllocSize;
	IMG_UINT32 ui32AllocOffset;
} RGX_FW_LAYOUT_ENTRY;

typedef struct
{
	IMG_UINT64 ui64BRNMaskSize;      /* BRN Mask size (in IMG_UINT64s) */
	IMG_UINT64 ui64ERNMaskSize;      /* ERN Mask size (in IMG_UINT64s) */
	IMG_UINT64 ui64FeatureMaskSize;  /* Feature Mask size (in IMG_UINT64s) */
	IMG_UINT64 ui64FeatureParamSize; /* Feature Parameter size (in IMG_UINT64s) */
} RGX_FW_DEVICE_INFO_HEADER;

#endif /* RGX_FW_INFO_H */

/******************************************************************************
 End of file (rgx_fw_info.h)
******************************************************************************/

/*************************************************************************/ /*!
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#if !defined(DC_PDP_H)
#define DC_PDP_H

#include "img_types.h"
#include "pvrsrv_error.h"
#include "powervr/imgpixfmts.h"
#include "pvrsrv.h"
#include "dc_osfuncs.h"
#include "plato.h"

#if defined(PLATO_DISPLAY_PDUMP)
#include "plato_pdump.h"
#endif

#define DRVNAME	"dc_pdp2"


/*************************************************************************/ /*!
 PCI Device Information
*/ /**************************************************************************/

#define DCPDP2_VENDOR_ID_PLATO			(0x1AEE)
#define DCPDP2_DEVICE_ID_PCI_PLATO		(0x0003)

/*************************************************************************/ /*!
 PCI Device Base Address Information
*/ /**************************************************************************/

/* PDP registers on base address register 1 */
#define DCPDP2_REG_PCI_BASENUM			(1)

#define DCPDP2_PCI_PDP_REG_OFFSET		(0x200000)
#define DCPDP2_PCI_PDP_REG_SIZE			(0x20000)

#define DCPDP2_BIF_REGS_OFFSET			(0x1000)
/*************************************************************************/ /*!
 dc_pdp OS functions
*/ /**************************************************************************/

typedef struct DCPDP_MODULE_PARAMETERS_TAG
{
	IMG_UINT32  ui32PDPEnabled;
	IMG_UINT32  ui32PDPWidth;
	IMG_UINT32  ui32PDPHeight;
} DCPDP_MODULE_PARAMETERS;

const DCPDP_MODULE_PARAMETERS *DCPDPGetModuleParameters(void);

/*************************************************************************/ /*!
 dc_pdp Timing definitions
*/ /**************************************************************************/
#define DCPDP_MAX_COMMANDS_INFLIGHT	(2)

/* This has to be less than or equal to the size of the type
   used for ui32BufferUseMask in the DCPDP_DEVICE structure */
#define DCPDP_MAX_BUFFERS		(32)

#define DCPDP_MIN_DISPLAY_PERIOD	(0)
#define DCPDP_MAX_DISPLAY_PERIOD	(2)

#define DCPDP_PIXEL_FORMAT		IMG_PIXFMT_B8G8R8A8_UNORM
#define DCPDP_PIXEL_FORMAT_BPP		(4)

// Graphics/video pixel format:
// 00000b 8-bit indexed (greyscale if LUT turned off) [RGB]
// 00100b 4-bit alpha + 12-bit rgb444 [ARGB]
// 00101b 1-bit alpha + 15-bit rgb555 [ARGB]
// 00110b 24-bit rgb888 [RGB]
// 00111b 16-bit rgb565 [RGB]
// 01000b 8-bit alpha + 24-bit rgb888 [RGBA]
// 10000b 8-bit alpha + 24-bit yuv888 [AYUV]
// 10101b 30-bit YUV 4:4:4 YUV101010 [YUV]
// 10110b 32-bit RGBX [RGBA]
#define DCPDP_PIXEL_FORMAT_G		(0x00)
#define DCPDP_PIXEL_FORMAT_ARGB4	(0x04)
#define DCPDP_PIXEL_FORMAT_ARGB1555	(0x05)
#define DCPDP_PIXEL_FORMAT_RGB8		(0x06)
#define DCPDP_PIXEL_FORMAT_RGB565	(0x07)
#define DCPDP_PIXEL_FORMAT_ARGB8	(0x08)
#define DCPDP_PIXEL_FORMAT_AYUV8	(0x10)
#define DCPDP_PIXEL_FORMAT_YUV10	(0x15)
#define DCPDP_PIXEL_FORMAT_RGBA8	(0x16)

/* Divide by 32, even though spec says to divide by 16 */
#define PDP_GRPH1STRIDE_DIVIDE 5

#ifndef DCPDP_DPI
#define DCPDP_DPI			(160)
#endif

/* For reduced blanking displays, VEVENT needs to be right after VBBS */
#define DCPDP_REDUCED_BLANKING_VEVENT	(1)

/*************************************************************************/ /*!
 dc_pdp Data structures
*/ /**************************************************************************/
typedef struct DCPDP_BUFFER_TAG DCPDP_BUFFER;
typedef struct DCPDP_FLIP_CONFIG_TAG DCPDP_FLIP_CONFIG;
typedef struct DCPDP_FLIP_CONTEXT_TAG DCPDP_FLIP_CONTEXT;
typedef struct DCPDP_DEVICE_TAG DCPDP_DEVICE;

typedef struct DCPDP_TIMING_DATA_TAG
{
	IMG_UINT32		ui32HDisplay;
	IMG_UINT32		ui32HBackPorch;
	IMG_UINT32		ui32HTotal;
	IMG_UINT32		ui32HActiveStart;
	IMG_UINT32		ui32HLeftBorder;
	IMG_UINT32		ui32HRightBorder;
	IMG_UINT32		ui32HFrontPorch;

	IMG_UINT32		ui32VDisplay;
	IMG_UINT32		ui32VBackPorch;
	IMG_UINT32		ui32VTotal;
	IMG_UINT32		ui32VActiveStart;
	IMG_UINT32		ui32VTopBorder;
	IMG_UINT32		ui32VBottomBorder;
	IMG_UINT32		ui32VFrontPorch;

	IMG_UINT8		ui8VSyncPolarity;
	IMG_UINT8		ui8HSyncPolarity;

	IMG_UINT32		ui32VRefresh;
	IMG_UINT32		ui32ClockFreq;

	IMG_BOOL		bReducedBlanking;
} DCPDP_TIMING_DATA;

struct DCPDP_BUFFER_TAG
{
	ATOMIC_T		i32RefCount;

	DCPDP_DEVICE		*psDeviceData;

	IMG_UINT32		ui32Width;
	IMG_UINT32		ui32Height;
	IMG_UINT32		ui32ByteStride;
	IMG_UINT32		ui32SizeInBytes;
	IMG_UINT32		ui32SizeInPages;
	IMG_PIXFMT		ePixelFormat;

	IMG_CPU_PHYADDR		sCpuPAddr;
	IMG_DEV_PHYADDR		sDevPAddr;

#if defined(PDP_DEBUG)
	DLLIST_NODE		sDbgListNode;		/* Linked list of buffers per-device */
#endif
};

typedef enum DCPDP_FLIP_CONFIG_STATUS_TAG
{
	DCPDP_FLIP_CONFIG_INACTIVE = 0,
	DCPDP_FLIP_CONFIG_PENDING,
	DCPDP_FLIP_CONFIG_ACTIVE,
} DCPDP_FLIP_CONFIG_STATUS;


/* Flip config structure used for queuing of flips */
struct DCPDP_FLIP_CONFIG_TAG
{
	/* Context with which this config is associated */
	DCPDP_FLIP_CONTEXT	*psContext;

	/* Services config data */
	IMG_HANDLE		hConfigData;

	/* Current status of the config */
	DCPDP_FLIP_CONFIG_STATUS eStatus;

	/* Buffer to be displayed when the config is made active */
	DCPDP_BUFFER		*psBuffer;

	/* Number of frames for which this config should remain active */
	IMG_UINT32		ui32DisplayPeriod;

	/* New mode to possibly switch to after flip */
	PVRSRV_SURFACE_CONFIG_INFO *pasSurfAttrib;

	/* Handle to a work item that processes the flip config queue */
	IMG_HANDLE		hWorkItem;
};

struct DCPDP_FLIP_CONTEXT_TAG
{
	/* Device on which the context has been created */
	DCPDP_DEVICE		*psDeviceData;

	/* Lock protecting the queue of flip configs */
	DC_SPINLOCK		sSpinLock;

	/* Mutex to serialise calls back into Services */
	void			*pvMutex;

	/* Queue of configs that need processing */
	DCPDP_FLIP_CONFIG	asFlipConfigQueue[DCPDP_MAX_COMMANDS_INFLIGHT];
	IMG_UINT32		ui32FlipConfigInsertIndex;
	IMG_UINT32		ui32FlipConfigRemoveIndex;

	/* Handle to a work queue used to defer the processing of the
	   flip config queue when a vsync interrupt is serviced */
	IMG_HANDLE		hFlipConfigWorkQueue;

	/* Services config data to retire */
	IMG_HANDLE		hConfigDataToRetire;
};

struct DCPDP_DEVICE_TAG
{
	IMG_HANDLE              hPVRServicesConnection;
	IMG_HANDLE              hPVRServicesDevice;
	DC_SERVICES_FUNCS       sPVRServicesFuncs;

	void                    *pvDevice;

	IMG_HANDLE              hLISRData;

	PHYS_HEAP               *psPhysHeap;

	IMG_CPU_PHYADDR         sPDPRegCpuPAddr;
	IMG_CPU_VIRTADDR        pvPDPRegCpuVAddr;

	IMG_CPU_VIRTADDR        pvPDPBifRegCpuVAddr;

	IMG_CPU_PHYADDR         sDispMemCpuPAddr;
	IMG_UINT64              uiDispMemSize;

	IMG_UINT32              uiTimingDataIndex;
	DCPDP_TIMING_DATA       *pasTimingData;
	IMG_UINT32              uiTimingDataSize;
	IMG_PIXFMT              ePixelFormat;

	IMG_UINT32              ui32BufferSize;
	IMG_UINT32              ui32BufferCount;
	IMG_UINT32              ui32BufferUseMask;

	DCPDP_BUFFER            *psSystemBuffer;

	DCPDP_FLIP_CONTEXT      *psFlipContext;

	IMG_BOOL                bVSyncEnabled;
	IMG_BOOL                bVSyncReporting;
	IMG_INT64               i64LastVSyncTimeStamp;
	IMG_HANDLE              hVSyncWorkQueue;
	IMG_HANDLE              hVSyncWorkItem;

	IMG_BOOL                bPreInitDone;

#if defined(ENABLE_PLATO_HDMI)
	VIDEO_PARAMS            videoParams;
#endif
#if defined(PDP_DEBUG)
	DLLIST_NODE             sDbgListNode;            /* Linked list of debug devices
	                                                    used by common layer */
	DLLIST_NODE             sDbgBufListHead;         /* Head of linked buffers
	                                                    for this device */
#endif
	DLLIST_NODE             sListNode;               /* Linked list of devices
	                                                    used by OS driver layer */
	IMG_UINT32              ui32Instance;            /* Device instance # */
	struct dentry           *psDebugFSEntryDir;      /* Device-specific debugFS directory */
	struct dentry           *psDisplayEnabledEntry;  /* 'display_enabled' debugFSentry for device */
	IMG_BOOL                bPDPEnabled;             /* State of 'display_enabled' setting */
};

/*******************************************************************************
 * dc_pdp common functions
 ******************************************************************************/

PVRSRV_ERROR DCPDPInit(void *pvDevice, DCPDP_DEVICE **ppsDeviceData, IMG_UINT32 ui32Instance);
PVRSRV_ERROR DCPDPStart(DCPDP_DEVICE *psDeviceData);
void DCPDPDeInit(DCPDP_DEVICE *psDeviceData, void **ppvDevice);

void DCPDPEnableMemoryRequest(DCPDP_DEVICE *psDeviceData, IMG_BOOL bEnable);
#if defined(PDP_DEBUG)
void PDPDebugCtrl(void);
#endif /* PDP_DEBUG */

#if defined(PLATO_DISPLAY_PDUMP)
void PDP_OSWriteHWReg32(void *pvLinRegBaseAddr, IMG_UINT32 ui32Offset, IMG_UINT32 ui32Value);
#endif

#endif /* !defined(DC_PDP_H) */

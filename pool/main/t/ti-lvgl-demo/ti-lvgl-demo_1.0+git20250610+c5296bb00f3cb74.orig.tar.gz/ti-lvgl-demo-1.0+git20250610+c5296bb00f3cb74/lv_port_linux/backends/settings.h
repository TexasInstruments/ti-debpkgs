#include <stdbool.h>
#include <stdint.h>

/* Settings defined in main.c */

extern uint16_t window_width;
extern uint16_t window_height;

extern bool fullscreen;
extern bool maximize;


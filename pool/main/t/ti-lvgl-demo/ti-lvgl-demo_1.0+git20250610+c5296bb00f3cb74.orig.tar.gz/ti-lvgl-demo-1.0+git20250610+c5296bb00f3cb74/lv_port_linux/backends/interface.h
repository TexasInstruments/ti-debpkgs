
/* Enters the run loop of the selected backend */
void lv_linux_run_loop(void);

/* Initializes the display */
void lv_linux_disp_init(void);

#if LV_BUILD_TEST
#include <stdio.h>
#include "../../lvgl.h"

int main(void)
{
    lv_init();
    return 0;
}
#endif

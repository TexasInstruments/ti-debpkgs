#!/bin/sh

PHY=`ls /sys/class/ieee80211/`

echo "$1" > /sys/kernel/debug/ieee80211/$PHY/cc33xx/dtim_interval

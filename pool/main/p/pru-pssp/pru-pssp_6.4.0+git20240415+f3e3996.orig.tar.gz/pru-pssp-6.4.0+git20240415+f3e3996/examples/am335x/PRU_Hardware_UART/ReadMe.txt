PRU firmware showing a different implementation of controlling the PRU Hardware
UART can be found under pru_cape/pru_fw/PRU_Hardware_UART.

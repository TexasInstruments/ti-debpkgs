works with CCS build only as it has sysconfig dependency

these examples and instructions will be added to the Getting_Started_Labs in a future PSSP release

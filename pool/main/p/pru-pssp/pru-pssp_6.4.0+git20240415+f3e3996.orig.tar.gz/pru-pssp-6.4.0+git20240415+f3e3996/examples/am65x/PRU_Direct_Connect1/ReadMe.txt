The FAQ for running this example is in the Direct_Connect0 folder at
../PRU_Direct_Connect0/ReadMe.txt

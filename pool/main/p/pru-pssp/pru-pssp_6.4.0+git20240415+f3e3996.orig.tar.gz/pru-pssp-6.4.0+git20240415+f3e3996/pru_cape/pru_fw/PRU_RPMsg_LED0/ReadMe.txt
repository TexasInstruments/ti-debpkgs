PRU_RPMsg_LED0
--------------

PRU_RPMsg_LED0 can be controlled by writing directly to the /dev/rpmsg_pru30
entry from the command line, or by running the example script pru0_led.sh.
For an example of writing to /dev/rpmsg_pruX from the command line, reference
the RPMsg Quick Start Guide.

PRU firmware showing a different implementation of controlling the PRU Hardware
UART can be found under examples/am335x/PRU_Hardware_UART.

#ifndef __sorte_g_cmd_def_h__
#define __sorte_g_cmd_def_h__

#define CMD_RESET_FSM_SHIFT   1

#endif // __sorte_g_cmd_def_h__

works with CCS build and makefile build

these examples and instructions will be added to the Getting_Started_Labs in a future PSSP release

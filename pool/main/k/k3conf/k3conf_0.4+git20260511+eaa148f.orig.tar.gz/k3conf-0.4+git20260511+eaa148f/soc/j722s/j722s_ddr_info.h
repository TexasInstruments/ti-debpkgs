/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * J722S DDR performance information
 *
 * Copyright (C) 2026 Texas Instruments Incorporated - https://www.ti.com/
 */

#ifndef __J722S_DDRBW_INFO_H
#define __J722S_DDRBW_INFO_H

extern struct ddr_perf_soc_info j722s_ddr_perf_info;

#endif /* __J722S_DDRBW_INFO_H */

#!/bin/sh
# Kill existing instances
killall -q micropython
# Wait a brief moment
sleep 0.5
# Run the app
SCRIPT_DIR="$(dirname "$(realpath "$0")")"
APP_DIR="$(dirname "$SCRIPT_DIR")"
cd "$APP_DIR"
./micropython main.py

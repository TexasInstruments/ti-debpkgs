Programmable Real-time Unit (PRU) Software Support Package
------------------------------------------------------------
============================================================
   INCLUDE
============================================================

DESCRIPTION

   This directory provides header files for PRU firmware.

   For more details about these header files, visit:

       https://software-dl.ti.com/processor-sdk-linux/esd/AM64X/latest/exports/docs/common/PRU-ICSS/Header_Files.html



ADDITIONAL RESOURCES

   For more information about the PRU, visit:

	PRU-ICSS/PRU_ICSSG docs  - https://software-dl.ti.com/processor-sdk-linux/esd/AM64X/latest/exports/docs/linux/Foundational_Components_PRU_Subsystem.html
        Support                  - http://e2e.ti.com

